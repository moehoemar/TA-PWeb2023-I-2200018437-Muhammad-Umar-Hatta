function validateForm(formId) {

  var xhr = new XMLHttpRequest();
  var formData = new FormData(document.getElementById("orderForm" + formId));

  xhr.onreadystatechange = function () {
    if (xhr.readyState === 4) {
      if (xhr.status === 200) {
        console.log("Pesanan berhasil disimpan ke file.");
      } else {
        console.log("Gagal menyimpan pesanan ke file.");
      }
    }
  };

  xhr.open("POST", "phpresponsi.php", true);
  xhr.send(formData);

  return false; 
}
