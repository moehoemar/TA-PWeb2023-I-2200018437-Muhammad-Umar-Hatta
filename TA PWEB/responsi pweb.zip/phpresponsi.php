<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
  $name = $_POST["name"];
  $quantity = $_POST["quantity"];
  $address = $_POST["address"];

  
  $data = "Nama: $name\nJumlah: $quantity\nAlamat Pengiriman: $address\n\n";

  
  $filename = "pesanan.txt";

  
  $file = fopen($filename, "a");

  if ($file) {
    // Menulis data ke file
    fwrite($file, $data);

    // Menutup file
    fclose($file);

    http_response_code(200); 
  } else {
    http_response_code(500); 
  }
}
?>
